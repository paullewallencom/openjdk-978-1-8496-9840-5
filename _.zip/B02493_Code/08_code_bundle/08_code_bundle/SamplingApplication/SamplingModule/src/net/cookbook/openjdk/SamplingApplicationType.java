/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*package net.cookbook.openjdk;

import com.sun.tools.visualvm.application.type.ApplicationType;
import java.awt.Image;
import static net.cookbook.openjdk.SamplingView.IMAGE_PATH;
import org.openide.util.Utilities;

public class SamplingApplicationType extends ApplicationType {
    protected final int pid;
    
    public SamplingApplicationType(int pid) {
        this.pid = pid;
    }

    @Override
    public String getName() {
        return "Sampling application";
    }

    @Override
    public String getVersion() {
        return "1.0";
    }

    @Override
    public String getDescription() {
        return "Provides some samples";
    }

    @Override
    public Image getIcon() {
        return Utilities.loadImage(SamplingView.IMAGE_PATH, true);
    }
    
}
*/