/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*package net.cookbook.openjdk;

import com.sun.tools.visualvm.application.Application;
import com.sun.tools.visualvm.application.type.ApplicationType;
import com.sun.tools.visualvm.core.model.AbstractModelProvider;

public class SamplingApplicationTypeProvider extends AbstractModelProvider<ApplicationType, Application> {
    @Override
    public ApplicationType createModelFor(Application app) {
        return new SamplingApplicationType(app.getPid());
    }
}
*/